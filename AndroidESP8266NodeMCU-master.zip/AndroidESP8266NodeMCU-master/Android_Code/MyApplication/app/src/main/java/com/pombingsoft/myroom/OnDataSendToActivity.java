package com.pombingsoft.myroom;

/**
 * Created by dzulkiflee on 3/19/2017 AD.
 */

public interface OnDataSendToActivity {
    public void sendData(String str);
}
